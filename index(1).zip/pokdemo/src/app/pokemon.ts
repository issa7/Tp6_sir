export class Pokemon {
}
